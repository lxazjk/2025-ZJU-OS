#pragma once

void intr_enable(void);

void intr_disable(void);

void idt_init(void);

void init(void);