#pragma once
#include "defs.h"

int puts(char *str);
int put_num(uint64_t n);