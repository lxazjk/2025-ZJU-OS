#pragma once

void init();
